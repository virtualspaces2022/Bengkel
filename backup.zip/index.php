
<?php include('include/header.php'); ?>

<?php echo 'test' ?>

<?php include('include/footer.php'); ?>