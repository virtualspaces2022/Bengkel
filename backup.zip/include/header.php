<?php include('config/setting.php');?>
<html>
    <head>
        <title>My Site</title>
      <link href="css/bootstrap.css" 
      rel="stylesheet">
    </head>
    <body>
