<?php

phpinfo();


?>